import { useEffect, useState } from "react";

export default function Home() {
  const [isFormLoaded, setIsFormLoaded] = useState(false);

  useEffect(() => {
    // Create and append the JotForm script
    const script = document.createElement("script");
    script.type = "text/javascript";
    script.src = "https://form.jotform.com/jsform/251894826975073";
    script.async = true;
    
    const container = document.getElementById("jotform-container");
    if (container) {
      container.appendChild(script);
    }

    // Check if form is loaded
    const checkFormLoaded = () => {
      const jotformFrame = document.querySelector('iframe[src*="jotform"]');
      if (jotformFrame) {
        setIsFormLoaded(true);
        // Ensure form is responsive
        jotformFrame.style.width = "100%";
        jotformFrame.style.minHeight = "400px";
      } else {
        setTimeout(checkFormLoaded, 100);
      }
    };

    setTimeout(checkFormLoaded, 500);

    // Cleanup function
    return () => {
      if (container) {
        container.innerHTML = "";
      }
    };
  }, []);

  useEffect(() => {
    // Responsive form height adjustment
    const adjustFormHeight = () => {
      const jotformFrame = document.querySelector('iframe[src*="jotform"]');
      if (jotformFrame) {
        jotformFrame.style.width = "100%";
        jotformFrame.style.minHeight = "400px";
      }
    };

    window.addEventListener("resize", adjustFormHeight);
    return () => window.removeEventListener("resize", adjustFormHeight);
  }, []);

  return (
    <div className="min-h-screen gradient-bg flex flex-col">
      {/* Main Content Area */}
      <main className="flex-1 flex items-center justify-center p-4 sm:p-6 lg:p-8">
        <div className="w-full max-w-2xl">
          {/* JotForm Container */}
          <div className="bg-white/95 backdrop-blur-sm rounded-2xl shadow-2xl p-6 sm:p-8 transition-all duration-300 hover:shadow-3xl jotform-container">
            {/* JotForm Embedded Script */}
            <div id="jotform-container" className="w-full"></div>
            
            {/* Loading State */}
            {!isFormLoaded && (
              <div className="text-center py-12">
                <div className="loading-spinner mx-auto mb-4"></div>
                <p className="text-gray-600 text-lg">Loading form...</p>
              </div>
            )}
          </div>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white/10 backdrop-blur-sm border-t border-white/20 py-4 sm:py-6">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <p className="text-white/80 text-sm">
              © 2025 囍雅傳聲 Heya Media. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
