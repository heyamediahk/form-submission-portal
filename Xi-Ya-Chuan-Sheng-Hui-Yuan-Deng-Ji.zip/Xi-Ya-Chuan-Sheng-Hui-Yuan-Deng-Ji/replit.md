# Form Submission Portal

## Overview

This is a full-stack React application with an Express backend that provides a form submission portal. The application integrates with JotForm for form handling and uses shadcn/ui components for a modern, responsive user interface. The architecture supports PostgreSQL with Drizzle ORM for data management and includes comprehensive UI components for future expansion.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **UI Library**: shadcn/ui components built on Radix UI primitives
- **Styling**: Tailwind CSS with CSS custom properties for theming
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Form Integration**: JotForm embedded forms with responsive design

### Backend Architecture
- **Runtime**: Node.js with Express.js framework
- **Language**: TypeScript with ESM modules
- **Database**: PostgreSQL with Drizzle ORM
- **Database Provider**: Neon serverless PostgreSQL
- **Session Management**: Connect-pg-simple for PostgreSQL-backed sessions
- **Development**: Hot reloading with Vite integration in development mode

### Data Storage
- **ORM**: Drizzle ORM with PostgreSQL dialect
- **Schema**: Centralized schema definition in shared directory
- **Migrations**: Automated schema migrations with Drizzle Kit
- **Development Storage**: In-memory storage implementation for development
- **Validation**: Zod schemas for runtime type validation

## Key Components

### Frontend Components
- **Home Page**: JotForm integration with responsive iframe handling
- **UI Components**: Complete shadcn/ui component library including:
  - Forms, inputs, and validation components
  - Navigation and layout components
  - Data display components (tables, cards, charts)
  - Interactive components (dialogs, tooltips, dropdowns)
  - Feedback components (toasts, alerts)

### Backend Components
- **Storage Interface**: Abstracted storage layer with in-memory and database implementations
- **Route System**: Modular route registration with Express
- **Development Tools**: Vite integration for hot reloading and development experience
- **Error Handling**: Centralized error handling middleware

### Database Schema
- **Users Table**: Basic user management with username/password authentication
- **Schema Validation**: Drizzle-Zod integration for type-safe database operations

## Data Flow

1. **Form Submission**: Users interact with embedded JotForm on the home page
2. **Client-Server Communication**: TanStack Query handles API requests with built-in caching
3. **Database Operations**: Drizzle ORM provides type-safe database interactions
4. **Session Management**: PostgreSQL-backed sessions for user authentication
5. **Error Handling**: Centralized error handling with user-friendly error messages

## External Dependencies

### Core Dependencies
- **@neondatabase/serverless**: Serverless PostgreSQL connection
- **@tanstack/react-query**: Server state management
- **drizzle-orm**: Database ORM with PostgreSQL support
- **express**: Backend web framework
- **react**: Frontend framework
- **tailwindcss**: Utility-first CSS framework

### UI Dependencies
- **@radix-ui/***: Accessible UI primitives
- **shadcn/ui**: Pre-built component library
- **lucide-react**: Icon library
- **class-variance-authority**: Type-safe CSS class variants

### Development Dependencies
- **vite**: Build tool and development server
- **typescript**: Type checking and compilation
- **tsx**: TypeScript execution for development

## Deployment Strategy

### Build Process
1. **Frontend Build**: Vite builds React application to `dist/public`
2. **Backend Build**: ESBuild bundles Express server to `dist/index.js`
3. **Database Setup**: Drizzle migrations applied with `db:push` command

### Environment Configuration
- **DATABASE_URL**: PostgreSQL connection string (required)
- **NODE_ENV**: Environment mode (development/production)
- **REPL_ID**: Replit-specific environment variable for development tools

### Production Deployment
- **Server**: Node.js server serving both API and static files
- **Database**: Neon PostgreSQL serverless database
- **Static Files**: Frontend assets served from Express in production
- **Session Storage**: PostgreSQL-backed session store for scalability

### Development Workflow
- **Hot Reloading**: Vite integration provides instant feedback
- **Database Development**: In-memory storage for rapid prototyping
- **Type Safety**: Full TypeScript coverage across frontend and backend
- **Development Tools**: Replit-specific tools for enhanced development experience